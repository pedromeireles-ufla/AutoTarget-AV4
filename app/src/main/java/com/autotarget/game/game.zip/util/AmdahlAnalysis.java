package com.autotarget.game.util;

import android.content.Context;
import android.util.Log;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Análise de Amdahl — AV4 b + c.
 *
 * METODOLOGIA (janela de tempo fixa / throughput):
 *   Para cada configuração (N núcleos, T threads), as T threads rodam durante
 *   JANELA_MS e contam iterações concluídas.
 *   S(N) = throughput(N) / throughput(1).
 *
 * AV4 c — MELHORIA: ThreadPoolExecutor com Thread.MAX_PRIORITY.
 *   ANTES : Executors.newFixedThreadPool — prioridade padrão.
 *   DEPOIS: ThreadPoolExecutor + ThreadFactory com Thread.MAX_PRIORITY (10).
 */
public final class AmdahlAnalysis {

    public static final String TAG = "AV4_AMDAHL";

    private static final long  JANELA_MS    = 2_000L;
    private static final long  WARMUP_MS    = 500L;
    private static final int   CPU_POR_PASSO = 15_000;
    private static final int[] QTDS_THREADS  = {10, 20, 50, 100};
    private static final float LARGURA = 1080f;
    private static final float ALTURA  = 1920f;

    private AmdahlAnalysis() {}

    // =========================================================================
    // Tipos públicos
    // =========================================================================

    public static final class Medicao {
        public final int     nucleos;
        public final int     threads;
        public final long    duracaoMs;
        public final long    iteracoes;
        public final double  throughput;
        public final boolean otimizado;

        Medicao(int nucleos, int threads, long duracaoMs, long iteracoes, boolean otimizado) {
            this.nucleos    = nucleos;
            this.threads    = threads;
            this.duracaoMs  = duracaoMs;
            this.iteracoes  = iteracoes;
            this.throughput = duracaoMs > 0 ? iteracoes / (duracaoMs / 1000.0) : 0;
            this.otimizado  = otimizado;
        }
    }

    public static final class PontoSpeedup {
        public final int     threads;
        public final int     nucleos;
        public final double  speedupExp;
        public final double  p;
        public final boolean otimizado;

        PontoSpeedup(int threads, int nucleos, double speedupExp, double p, boolean otimizado) {
            this.threads    = threads;
            this.nucleos    = nucleos;
            this.speedupExp = speedupExp;
            this.p          = p;
            this.otimizado  = otimizado;
        }
    }

    public static final class Resultado {
        public final File   reportFile;
        public final File   svgFile;
        public final String reportText;

        Resultado(File reportFile, File svgFile, String reportText) {
            this.reportFile = reportFile;
            this.svgFile    = svgFile;
            this.reportText = reportText;
        }
    }

    // =========================================================================
    // Ponto de entrada
    // =========================================================================

    public static Resultado executarAnalise(Context context) {
        int coresDisp = Math.max(1, Runtime.getRuntime().availableProcessors());
        List<Integer> configNucleos = buildConfigNucleos(coresDisp);

        aquecerJIT();

        Log.e(TAG, "=== Análise de Amdahl AV4 b+c | Cores=" + coresDisp + " Configs=" + configNucleos);

        // Fase ANTES
        Log.e(TAG, "-- ANTES (pool padrão) --");
        List<Medicao> medicoesAntes = new ArrayList<>();
        for (int nucleos : configNucleos) {
            for (int t : QTDS_THREADS) {
                Medicao m = medirCiclo(nucleos, t, false);
                medicoesAntes.add(m);
                Log.e(TAG, String.format(Locale.US, "  ANTES  N=%d T=%d -> %.0f iter/s", nucleos, t, m.throughput));
            }
        }

        // Fase DEPOIS
        Log.e(TAG, "-- DEPOIS (pool otimizado) --");
        List<Medicao> medicoesDepois = new ArrayList<>();
        for (int nucleos : configNucleos) {
            for (int t : QTDS_THREADS) {
                Medicao m = medirCiclo(nucleos, t, true);
                medicoesDepois.add(m);
                Log.e(TAG, String.format(Locale.US, "  DEPOIS N=%d T=%d -> %.0f iter/s", nucleos, t, m.throughput));
            }
        }

        List<PontoSpeedup> pontosAntes  = calcularSpeedups(medicoesAntes,  configNucleos, false);
        List<PontoSpeedup> pontosDepois = calcularSpeedups(medicoesDepois, configNucleos, true);

        File dir = new File(context.getExternalFilesDir(null), "amdahl");
        if (!dir.exists()) dir.mkdirs();

        File svgFile    = new File(dir, "grafico_amdahl.svg");
        File reportFile = new File(dir, "relatorio_amdahl.txt");

        gerarSvg(svgFile, pontosAntes, pontosDepois, configNucleos);
        String texto = gerarRelatorio(coresDisp, configNucleos,
                medicoesAntes, medicoesDepois, pontosAntes, pontosDepois);
        salvarTexto(reportFile, texto);

        Log.e(TAG, "SVG: " + svgFile.getAbsolutePath());
        Log.e(TAG, "TXT: " + reportFile.getAbsolutePath());
        return new Resultado(reportFile, svgFile, texto);
    }

    // =========================================================================
    // Pools — ANTES e DEPOIS
    // =========================================================================

    private static ExecutorService criarPoolPadrao(int nucleos) {
        return Executors.newFixedThreadPool(nucleos);
    }

    private static ExecutorService criarPoolOtimizado(int nucleos) {
        AtomicInteger id = new AtomicInteger(0);
        ThreadFactory factory = r -> {
            Thread t = new Thread(r, "amdahl-" + id.getAndIncrement());
            t.setPriority(Thread.MAX_PRIORITY);
            t.setDaemon(true);
            return t;
        };
        int cap = Math.max(nucleos * 4, 16);
        BlockingQueue<Runnable> fila = new LinkedBlockingQueue<>(cap);
        return new ThreadPoolExecutor(nucleos, nucleos, 0L, TimeUnit.MILLISECONDS,
                fila, factory, new ThreadPoolExecutor.CallerRunsPolicy());
    }

    // =========================================================================
    // Aquecimento
    // =========================================================================

    private static void aquecerJIT() {
        for (int i = 0; i < 100; i++) cargaCPU(i, i, CPU_POR_PASSO);
    }

    private static void aquecerNucleos(ExecutorService pool, int nucleos) {
        CountDownLatch fim = new CountDownLatch(nucleos);
        long prazo = System.nanoTime() + WARMUP_MS * 1_000_000L;
        for (int i = 0; i < nucleos; i++) {
            pool.submit(() -> {
                double acc = 0;
                while (System.nanoTime() < prazo) acc += cargaCPU((float) acc, 1f, CPU_POR_PASSO);
                fim.countDown();
            });
        }
        try { fim.await(WARMUP_MS * 4, TimeUnit.MILLISECONDS); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }

    // =========================================================================
    // Configuração de núcleos
    // =========================================================================

    private static List<Integer> buildConfigNucleos(int cores) {
        List<Integer> c = new ArrayList<>();
        c.add(1);
        if (cores >= 2) c.add(2);
        if (cores >= 4) c.add(4);
        if (cores > 4 && !c.contains(cores)) c.add(cores);
        return c;
    }

    // =========================================================================
    // Medição — janela de tempo fixa
    // =========================================================================

    private static Medicao medirCiclo(int nucleos, int qtdThreads, boolean otimizado) {
        ExecutorService pool = otimizado ? criarPoolOtimizado(nucleos) : criarPoolPadrao(nucleos);
        AtomicLong totalIteracoes = new AtomicLong(0);

        aquecerNucleos(pool, nucleos);

        CountDownLatch concluido = new CountDownLatch(qtdThreads);
        final long fimNanos = System.nanoTime() + JANELA_MS * 1_000_000L;

        long t0 = System.nanoTime();
        for (int i = 0; i < qtdThreads; i++) {
            final float px  = (float)(Math.random() * LARGURA);
            final float py  = (float)(Math.random() * ALTURA);
            final float vx0 = (float)(Math.random() * 6 - 3);
            final float vy0 = (float)(Math.random() * 6 - 3);
            pool.submit(() -> {
                float x = px, y = py, vx = vx0, vy = vy0;
                long local = 0;
                while (System.nanoTime() < fimNanos) {
                    x += vx; y += vy;
                    if (x < 0 || x > LARGURA) vx = -vx;
                    if (y < 0 || y > ALTURA)  vy = -vy;
                    cargaCPU(x, y, CPU_POR_PASSO);
                    local++;
                }
                totalIteracoes.addAndGet(local);
                concluido.countDown();
            });
        }

        try { concluido.await(JANELA_MS + 8_000L, TimeUnit.MILLISECONDS); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        long duracaoMs = Math.max(1, (System.nanoTime() - t0) / 1_000_000L);

        pool.shutdown();
        try { pool.awaitTermination(5, TimeUnit.SECONDS); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); }

        return new Medicao(nucleos, qtdThreads, duracaoMs, totalIteracoes.get(), otimizado);
    }

    private static double cargaCPU(float x, float y, int n) {
        double acc = x * 0.001 + y * 0.001;
        for (int i = 1; i <= n; i++)
            acc += Math.sqrt(Math.log(i) + Math.sin(i + acc * 1e-12));
        return acc;
    }

    // =========================================================================
    // Cálculo de speedup
    // =========================================================================

    private static List<PontoSpeedup> calcularSpeedups(List<Medicao> medicoes,
                                                        List<Integer> configNucleos,
                                                        boolean otimizado) {
        List<PontoSpeedup> pontos = new ArrayList<>();
        for (int t : QTDS_THREADS) {
            double tpBase = throughputDe(medicoes, 1, t);
            if (tpBase <= 0) continue;
            List<Integer> ns = new ArrayList<>();
            List<Double>  se = new ArrayList<>();
            for (int n : configNucleos) {
                double tp = throughputDe(medicoes, n, t);
                if (tp > 0) { ns.add(n); se.add(tp / tpBase); }
            }
            double p = estimarP(ns, se);
            for (int i = 0; i < ns.size(); i++)
                pontos.add(new PontoSpeedup(t, ns.get(i), se.get(i), p, otimizado));
        }
        return pontos;
    }

    private static double throughputDe(List<Medicao> ms, int nucleos, int threads) {
        for (Medicao m : ms)
            if (m.nucleos == nucleos && m.threads == threads) return m.throughput;
        return 0;
    }

    private static double amdahl(double p, int n) {
        return 1.0 / ((1.0 - p) + (p / Math.max(1, n)));
    }

    private static double estimarP(List<Integer> ns, List<Double> se) {
        double melhor = 0, menor = Double.MAX_VALUE;
        for (int i = 0; i <= 1000; i++) {
            double p = i / 1000.0, e = 0;
            for (int j = 0; j < ns.size(); j++) {
                double d = se.get(j) - amdahl(p, ns.get(j));
                e += d * d;
            }
            if (e < menor) { menor = e; melhor = p; }
        }
        return melhor;
    }

    // =========================================================================
    // Relatório
    // =========================================================================

    private static String gerarRelatorio(int coresDisp, List<Integer> configs,
                                          List<Medicao> antes, List<Medicao> depois,
                                          List<PontoSpeedup> pAntes, List<PontoSpeedup> pDepois) {
        StringBuilder sb = new StringBuilder();
        sep(sb, '=', 72);
        sb.append("   ANÁLISE DE DESEMPENHO — LEI DE AMDAHL (AV4 b + c)\n");
        sep(sb, '=', 72);
        sb.append("\nCONFIGURAÇÃO\n");
        sb.append("  Janela de medição : ").append(JANELA_MS).append(" ms\n");
        sb.append("  Warmup            : ").append(WARMUP_MS).append(" ms\n");
        sb.append("  CPU por iteração  : ").append(CPU_POR_PASSO).append(" ops fp\n");
        sb.append("  Threads testadas  : 10, 20, 50, 100\n");
        sb.append("  Núcleos testados  : ").append(configs).append("\n");
        sb.append("  Cores físicos     : ").append(coresDisp).append("\n\n");

        sb.append("TABELA 1A — THROUGHPUT ANTES (pool padrão)\n");
        sep(sb, '-', 68);
        sb.append(String.format(Locale.US, "%-8s | %-8s | %-14s | %-12s | %-13s\n",
                "Threads","Núcleos","Iterações","Tempo(ms)","Thrput(i/s)"));
        sep(sb, '-', 68);
        for (Medicao m : antes)
            sb.append(String.format(Locale.US, "%-8d | %-8d | %-14d | %-12d | %-13.1f\n",
                    m.threads, m.nucleos, m.iteracoes, m.duracaoMs, m.throughput));
        sb.append("\n");

        sb.append("TABELA 1B — THROUGHPUT DEPOIS (pool otimizado)\n");
        sep(sb, '-', 68);
        sb.append(String.format(Locale.US, "%-8s | %-8s | %-14s | %-12s | %-13s\n",
                "Threads","Núcleos","Iterações","Tempo(ms)","Thrput(i/s)"));
        sep(sb, '-', 68);
        for (Medicao m : depois)
            sb.append(String.format(Locale.US, "%-8d | %-8d | %-14d | %-12d | %-13.1f\n",
                    m.threads, m.nucleos, m.iteracoes, m.duracaoMs, m.throughput));
        sb.append("\n");

        sb.append("TABELA 2 — COMPARAÇÃO ANTES × DEPOIS\n");
        sep(sb, '-', 60);
        sb.append(String.format(Locale.US, "%-8s | %-8s | %-13s | %-13s | %-8s\n",
                "Threads","Núcleos","Antes(i/s)","Depois(i/s)","Ganho %"));
        sep(sb, '-', 60);
        for (int t : QTDS_THREADS) {
            for (int n : configs) {
                double ta = throughputDe(antes,  n, t);
                double td = throughputDe(depois, n, t);
                double g  = ta > 0 ? (td - ta) / ta * 100.0 : 0;
                sb.append(String.format(Locale.US, "%-8d | %-8d | %-13.1f | %-13.1f | %+.1f%%\n",
                        t, n, ta, td, g));
            }
        }
        sb.append("\n");

        sb.append("TABELA 3 — SPEEDUP S(N)\n");
        sep(sb, '-', 60);
        sb.append(String.format(Locale.US, "%-8s | %-8s | %-12s | %-12s\n",
                "Threads","Núcleos","S(N) Antes","S(N) Depois"));
        sep(sb, '-', 60);
        for (int t : QTDS_THREADS) {
            for (int n : configs) {
                PontoSpeedup pa = buscar(pAntes,  t, n);
                PontoSpeedup pd = buscar(pDepois, t, n);
                sb.append(String.format(Locale.US, "%-8d | %-8d | %-12.3f | %-12.3f\n",
                        t, n,
                        pa != null ? pa.speedupExp : 0,
                        pd != null ? pd.speedupExp : 0));
            }
        }
        sb.append("\n");

        sb.append("DISCUSSÃO\n");
        sep(sb, '-', 72);
        sb.append("AV4 b — S(N) = throughput(N) / throughput(1). Com janela fixa de ")
          .append(JANELA_MS).append(" ms,\n");
        sb.append("  N workers simultâneos produzem mais iterações → throughput cresce → S(N) > 1.\n\n");
        sb.append("AV4 c — Melhoria: ThreadPoolExecutor com Thread.MAX_PRIORITY (10).\n");
        sb.append("  ANTES : Executors.newFixedThreadPool — prioridade NORM_PRIORITY (5).\n");
        sb.append("  DEPOIS: ThreadPoolExecutor + ThreadFactory com MAX_PRIORITY.\n");
        sb.append("  Workers sofrem menos preempção → mais iterações por janela → S(N) maior.\n");

        return sb.toString();
    }

    private static PontoSpeedup buscar(List<PontoSpeedup> lista, int threads, int nucleos) {
        for (PontoSpeedup p : lista)
            if (p.threads == threads && p.nucleos == nucleos) return p;
        return null;
    }

    private static void sep(StringBuilder sb, char c, int n) {
        for (int i = 0; i < n; i++) sb.append(c);
        sb.append('\n');
    }

    // =========================================================================
    // SVG — ANTES (tracejado) e DEPOIS (sólido), SEM curvas teóricas
    // =========================================================================

    private static void gerarSvg(File arquivo,
                                  List<PontoSpeedup> pontosAntes,
                                  List<PontoSpeedup> pontosDepois,
                                  List<Integer> configNucleos) {
        final int W         = 1000;
        final int PAD_L     = 80;
        final int PAD_R     = 30;
        final int PAD_TOP   = 80;
        final int CHART_H   = 390;
        final int LEG_H     = 85;
        final int H         = PAD_TOP + CHART_H + LEG_H;
        final int CHART_W   = W - PAD_L - PAD_R;
        final int CHART_BOT = PAD_TOP + CHART_H;

        double maxS = 1.2;
        int maxN = 1;
        for (PontoSpeedup p : pontosAntes)  { maxS = Math.max(maxS, p.speedupExp * 1.15); maxN = Math.max(maxN, p.nucleos); }
        for (PontoSpeedup p : pontosDepois) { maxS = Math.max(maxS, p.speedupExp * 1.15); maxN = Math.max(maxN, p.nucleos); }

        final String[] CORES = {"#1565C0", "#C62828", "#2E7D32", "#6A1B9A"};

        StringBuilder sb = new StringBuilder();
        sb.append(String.format("<svg width=\"%d\" height=\"%d\" viewBox=\"0 0 %d %d\" xmlns=\"http://www.w3.org/2000/svg\">\n", W, H, W, H));
        sb.append("<rect width=\"100%\" height=\"100%\" fill=\"#FAFAFA\"/>\n");

        // Título
        sb.append(String.format("<text x=\"%d\" y=\"28\" text-anchor=\"middle\" font-family=\"sans-serif\" font-size=\"16\" font-weight=\"bold\" fill=\"#212121\">Análise de Speedup — Lei de Amdahl (AV4 b+c)</text>\n", W/2));
        sb.append(String.format("<text x=\"%d\" y=\"50\" text-anchor=\"middle\" font-family=\"sans-serif\" font-size=\"11\" fill=\"#757575\">S(N) = throughput(N)/throughput(1) | Tracejado = ANTES (pool padrão) | Sólido = DEPOIS (pool otimizado)</text>\n", W/2));

        // Grade
        for (int i = 0; i <= 5; i++) {
            double s = maxS / 5.0 * i;
            float  y = CHART_BOT - (float)(s / maxS * CHART_H);
            sb.append(String.format("<line x1=\"%d\" y1=\"%.1f\" x2=\"%d\" y2=\"%.1f\" stroke=\"#E0E0E0\" stroke-dasharray=\"4,4\"/>\n", PAD_L, y, W-PAD_R, y));
            sb.append(String.format("<text x=\"%d\" y=\"%.1f\" text-anchor=\"end\" font-family=\"sans-serif\" font-size=\"11\" fill=\"#616161\">%.2fx</text>\n", PAD_L-6, y+4, s));
        }

        // Linha S=1
        float yRef = CHART_BOT - (float)(1.0 / maxS * CHART_H);
        sb.append(String.format("<line x1=\"%d\" y1=\"%.1f\" x2=\"%d\" y2=\"%.1f\" stroke=\"#BDBDBD\" stroke-width=\"1\" stroke-dasharray=\"2,2\"/>\n", PAD_L, yRef, W-PAD_R, yRef));
        sb.append(String.format("<text x=\"%d\" y=\"%.1f\" font-family=\"sans-serif\" font-size=\"10\" fill=\"#9E9E9E\">S=1</text>\n", PAD_L+4, yRef-3));

        // Séries por quantidade de threads
        for (int ci = 0; ci < QTDS_THREADS.length; ci++) {
            int    qtdT = QTDS_THREADS[ci];
            String cor  = CORES[ci % CORES.length];

            // ANTES — tracejado, pontos ocos
            StringBuilder ptsAntes = new StringBuilder();
            for (int nucleos : configNucleos) {
                PontoSpeedup pt = buscar(pontosAntes, qtdT, nucleos);
                if (pt == null) continue;
                float x = xPos(nucleos, maxN, PAD_L, CHART_W);
                float y = CHART_BOT - (float)(pt.speedupExp / maxS * CHART_H);
                ptsAntes.append(String.format(Locale.US, "%.1f,%.1f ", x, y));
                sb.append(String.format("<circle cx=\"%.1f\" cy=\"%.1f\" r=\"4\" fill=\"none\" stroke=\"%s\" stroke-width=\"1.5\"/>\n", x, y, cor));
            }
            if (ptsAntes.length() > 0)
                sb.append(String.format("<polyline points=\"%s\" fill=\"none\" stroke=\"%s\" stroke-width=\"2\" stroke-dasharray=\"10,5\"/>\n", ptsAntes.toString().trim(), cor));

            // DEPOIS — sólido, pontos cheios + rótulo
            StringBuilder ptsDepois = new StringBuilder();
            for (int nucleos : configNucleos) {
                PontoSpeedup pt = buscar(pontosDepois, qtdT, nucleos);
                if (pt == null) continue;
                float x = xPos(nucleos, maxN, PAD_L, CHART_W);
                float y = CHART_BOT - (float)(pt.speedupExp / maxS * CHART_H);
                ptsDepois.append(String.format(Locale.US, "%.1f,%.1f ", x, y));
                sb.append(String.format("<circle cx=\"%.1f\" cy=\"%.1f\" r=\"5\" fill=\"%s\"/>\n", x, y, cor));
                sb.append(String.format("<text x=\"%.1f\" y=\"%.1f\" text-anchor=\"middle\" font-family=\"sans-serif\" font-size=\"9\" fill=\"%s\">%.2f</text>\n", x, y-9, cor, pt.speedupExp));
            }
            if (ptsDepois.length() > 0)
                sb.append(String.format("<polyline points=\"%s\" fill=\"none\" stroke=\"%s\" stroke-width=\"2.5\"/>\n", ptsDepois.toString().trim(), cor));
        }

        // Eixos
        sb.append(String.format("<line x1=\"%d\" y1=\"%d\" x2=\"%d\" y2=\"%d\" stroke=\"#333\" stroke-width=\"2\"/>\n", PAD_L, CHART_BOT, W-PAD_R, CHART_BOT));
        sb.append(String.format("<line x1=\"%d\" y1=\"%d\" x2=\"%d\" y2=\"%d\" stroke=\"#333\" stroke-width=\"2\"/>\n", PAD_L, PAD_TOP, PAD_L, CHART_BOT));

        // Ticks eixo X
        for (int nucleos : configNucleos) {
            float x = xPos(nucleos, maxN, PAD_L, CHART_W);
            sb.append(String.format("<line x1=\"%.1f\" y1=\"%d\" x2=\"%.1f\" y2=\"%d\" stroke=\"#333\" stroke-width=\"1.5\"/>\n", x, CHART_BOT, x, CHART_BOT+6));
            sb.append(String.format("<text x=\"%.1f\" y=\"%d\" text-anchor=\"middle\" font-family=\"sans-serif\" font-size=\"12\" fill=\"#333\">%d</text>\n", x, CHART_BOT+20, nucleos));
        }

        // Labels eixos
        sb.append(String.format("<text x=\"%d\" y=\"%d\" text-anchor=\"middle\" font-family=\"sans-serif\" font-size=\"13\" fill=\"#424242\">Núcleos (N)</text>\n", W/2, CHART_BOT+38));
        sb.append(String.format("<text x=\"20\" y=\"%d\" transform=\"rotate(-90 20,%d)\" text-anchor=\"middle\" font-family=\"sans-serif\" font-size=\"13\" fill=\"#424242\">Speedup S(N)</text>\n", PAD_TOP+CHART_H/2, PAD_TOP+CHART_H/2));

        // Legenda — linha 1: cores por série de threads
        int legY1 = CHART_BOT + 50;
        int legStep = CHART_W / QTDS_THREADS.length;
        for (int ci = 0; ci < QTDS_THREADS.length; ci++) {
            int legX = PAD_L + ci * legStep;
            String cor = CORES[ci % CORES.length];
            sb.append(String.format("<rect x=\"%d\" y=\"%d\" width=\"14\" height=\"14\" fill=\"%s\"/>\n", legX, legY1, cor));
            sb.append(String.format("<text x=\"%d\" y=\"%d\" font-family=\"sans-serif\" font-size=\"12\" fill=\"#212121\">%d threads</text>\n", legX+18, legY1+11, QTDS_THREADS[ci]));
        }

        // Legenda — linha 2: ANTES / DEPOIS
        int legY2 = legY1 + 26;
        sb.append(String.format("<line x1=\"%d\" y1=\"%d\" x2=\"%d\" y2=\"%d\" stroke=\"#555\" stroke-width=\"2\" stroke-dasharray=\"10,5\"/>\n", PAD_L, legY2+6, PAD_L+28, legY2+6));
        sb.append(String.format("<text x=\"%d\" y=\"%d\" font-family=\"sans-serif\" font-size=\"11\" fill=\"#555\">ANTES (pool padrão)</text>\n", PAD_L+34, legY2+10));
        sb.append(String.format("<line x1=\"%d\" y1=\"%d\" x2=\"%d\" y2=\"%d\" stroke=\"#555\" stroke-width=\"2.5\"/>\n", PAD_L+210, legY2+6, PAD_L+238, legY2+6));
        sb.append(String.format("<text x=\"%d\" y=\"%d\" font-family=\"sans-serif\" font-size=\"11\" fill=\"#555\">DEPOIS (pool otimizado)</text>\n", PAD_L+244, legY2+10));

        sb.append("</svg>\n");
        salvarTexto(arquivo, sb.toString());
    }

    private static float xPos(int n, int maxN, int padL, int chartW) {
        return (maxN > 1) ? padL + (float)(n-1)/(maxN-1) * chartW : padL + chartW/2f;
    }

    // =========================================================================
    // Utilitário
    // =========================================================================

    private static void salvarTexto(File f, String texto) {
        try (FileWriter fw = new FileWriter(f)) { fw.write(texto); }
        catch (IOException e) { Log.e(TAG, "Erro ao salvar: " + f.getAbsolutePath(), e); }
    }
}
